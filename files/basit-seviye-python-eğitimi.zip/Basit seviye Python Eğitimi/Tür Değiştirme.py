isim = "Adem Yavuz"
yas = 15
print (isim + " " + str(yas) + " " + "yaşında")

# int()
# float()
# str()
# bool()


isciler = ["mehmet","mahmut","kerim","ali","abdullah"]
print(isciler[0])
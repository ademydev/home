yagmurlu = False
guneşli = False

if yagmurlu:
    print("Ceketini Giy!")

elif guneşli:                               #elif: aksi takdirde, eğer bu koşul doğruysa çalıştırılacak kod bloğu
    print("Güneş gözlüğünü tak!")

else:                                                  
    print("normal bir şekilde dışarı çıkabilirsin.")


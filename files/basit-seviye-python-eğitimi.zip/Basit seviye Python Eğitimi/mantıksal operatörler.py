ehliyet = True 
araba = True 

if ehliyet and araba: 
    print("araba kullanabilirsin")

elif araba and not ehliyet:
    print("bizim sürücü kursumuzu tercih ederek hemen araba kullanmaya başlayabilirsin.")

elif ehliyet or araba: 
    print("araba kullanmana çok az kaldı")

else: 
    print("araba kullanmana daha çoook var")


#and: hepsi doğru olduğu zaman
#or: sadece biri doğru olduğu zaman çalışır 
#not: ?


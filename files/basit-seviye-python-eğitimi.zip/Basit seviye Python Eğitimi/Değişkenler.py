x = 3
print (x)

isim = "muhammet" #string = yazı/metin tutar
fiyat = 13.95 #float = ondalık sayı tutar
AldıMı = False #boolean = doğru/yanlış değeri tutar
x = 3 # integer = tam sayı tutar


isim = "Moby Dick"
sayfa = 195
agirlik = 13.45
yenimi = True


print(isim)

print(type(agirlik))


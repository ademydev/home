sayı = int(input("ilk sayıyı giriniz: "))
sayı2 = int(input("ikinci sayıyı giriniz: "))
istenilenişlem = input("""Yapmak istediğiniz işlemi giriniz. 
(toplam: +, çıkarma: -, Çarpma: x, Bölme: /)
""")

if istenilenişlem == "+":
    print("sonuç: " + str(sayı+sayı2))

elif istenilenişlem == "-":
    print("sonuç: " + str(sayı - sayı2))

elif istenilenişlem == "x":
    print("sonuç: " + str(sayı * sayı2))

elif istenilenişlem == "/":
    print("sonuç: " + str(sayı / sayı2))



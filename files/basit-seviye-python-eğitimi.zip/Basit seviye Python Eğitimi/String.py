#isim = 'muh"a"mmet'

#mektup = """merhaba ahmet
#umarım iyisindir"""

#print (mektup)

isim = "ademYavuz"
       #012345678
print(isim[0:4])

print (len(isim))
print(isim.title())
print(isim.upper())  
print(isim.lower())

print(isim.find("a")) #python büyük, küçük harf duyarlıdır. a harfi 1. indexte olduğu için 1 döndürür.   
print(isim.find("A")) #A harfi olmadığı için -1 döndürür.
print(isim.replace("adem","ahmet")) #adem yerine ahmet yazdırır.

#ÖDEV

isim = input("isminiz nedir? ") 
print(isim.title()) #kullanıcıdan ismini al ve baş harfini büyük olarak yazdır


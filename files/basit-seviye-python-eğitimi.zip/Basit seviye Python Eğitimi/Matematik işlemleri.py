x = 5
y = 9

print (x + y)
print (x - y)
print (x * y)
print (x / y)

print (x ** y)
print (x // y)
print (x % y)

sayı = input("sayı giriniz: ")
sayı2 = input("ikinnci sayıyı giriniz: ")

print (float(sayı) + float(sayı2))
print (int(sayı) + int(sayı2))

#MATEMATİK FONKSİYONLARI
print(round(9.8))
print(abs(-9))

import math
print(math.sqrt(9))

print(min(9,10,11,12))
print(max(9,10,11,12))






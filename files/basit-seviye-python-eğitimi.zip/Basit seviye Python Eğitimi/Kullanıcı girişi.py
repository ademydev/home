#isim = input("isminiz nedir? ")
#print("merhaba "+isim)                      #kullanıcıdan ismini ve sevdiği yemeği al ve sonrasında .. .. sever olarak yazdır

kullanıcı = input("isminiz nedir? ")
kusevyemek = input("en sevdiğiniz yemek nedir? ")
print(kullanıcı+" "+kusevyemek+" "+"sever")

#<
#>
#>=
#>=
#==
#=!

# sıcaklık = 32 

# if sıcaklık >= 30:
#     print("hava çok sıcak")

# elif sıcaklık <= 0:
#     print("hava çok soğuk")


# sıcaklık = 41

# if sıcaklık != 40:
#     print("hava 40 derece değil")

# elif sıcaklık < 0:
#     print("hava çok soğuk")


#ÖDEV

# yas = 19 
# okulagidiyor = True

# if yas > 18 and not okulagidiyor:
#     print("askere gitme yaşınız geldi")

# elif yas > 18 and okulagidiyor:
#     print("okulunuz bittiğinde askere gideceksiniz")

# else:
#     print("okula gitme yaşınız gelmedi")


#ÖDEV DOĞRU YAPIMI 

yas = int(input("Yaşınızı Giriniz. "))
Okumadurumu = input("okuyor musunuz? (evet: e, hayır:h)")

if yas >= 18 and Okumadurumu == "h":
    print("Askere gitme yaşınız geldi.")

elif yas >= 18 and Okumadurumu == "e":
    print("okulunuz bittiğinde askere geleceksiniz.")

else: 
    print("daha askerlik yaşınız gelmedi.")









